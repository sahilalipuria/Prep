package com.logicbig.example;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("/")
public class UserResource {

    @POST
    @Path("users")
    public String createUser(@ValidRole User user) {
        System.out.println("-- in createUser() method --");
        return String.format("User created : %s%n", user);
    }

    @POST
    @Path("users2")
    public String createUser2(@Valid @ValidRole User user) {
        System.out.println("-- in createUser2() method --");
        return String.format("User created : %s%n", user);
    }
}