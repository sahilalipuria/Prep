package com.logicbig.example;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class MyClient {

    public static void main(String[] args) throws Exception {
        User user = new User();
        user.setName(null);
        user.setEmail("user-example.com");
        user.setRole("visitor");

        Client client = ClientBuilder.newBuilder().build();
        WebTarget target =
                client.target("http://localhost:8080/users");
        Response response = target.request()
                                .post(Entity.entity(user,
                                        MediaType.TEXT_XML), Response.class);
        System.out.println(response.readEntity(String.class));
    }
}