package com.logicbig.example;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Arrays;
import java.util.List;

public class UserRoleValidator implements
        ConstraintValidator<ValidRole, User> {

    private static final List<String> ALLOWED_ROLES = Arrays.asList("admin", "super-user");

    @Override
    public void initialize(ValidRole constraintAnnotation) {
    }

    @Override
    public boolean isValid(User user, ConstraintValidatorContext context) {
        return ALLOWED_ROLES.contains(user.getRole());
    }
}