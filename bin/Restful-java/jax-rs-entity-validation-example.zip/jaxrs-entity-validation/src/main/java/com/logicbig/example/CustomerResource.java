package com.logicbig.example;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("/customers")
public class CustomerResource {

    @POST
    public String createCustomer(@Valid Customer customer) {
        System.out.println("-- in createCustomer() method --");
        return String.format("Customer created : %s%n", customer);
    }
}