package com.logicbig.example;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;

@Path("/customers")
public class CustomerResource {

    @POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    public String createCustomer(@NotNull @FormParam("name") String name,
                                 @NotNull @FormParam("address") String address,
                                 @NotNull @Pattern(regexp = "\\d{3}-\\d{3}-\\d{4}")
                                 @FormParam("phone-number") String phoneNumber) {
        System.out.println("-- in createCustomer() method --");
        return String.format("created dummy customer name: %s, address: %s, phoneNumber:%s%n"
                , name, address, phoneNumber);

    }
}