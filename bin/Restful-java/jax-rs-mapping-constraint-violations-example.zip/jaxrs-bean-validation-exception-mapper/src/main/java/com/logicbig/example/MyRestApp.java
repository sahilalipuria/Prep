package com.logicbig.example;

import org.glassfish.jersey.filter.LoggingFilter;
import org.glassfish.jersey.logging.LoggingFeature;
import org.glassfish.jersey.server.ResourceConfig;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class MyRestApp extends Application{}
/* extends ResourceConfig {

    public MyRestApp() {


      //  en
        //  register(new YamlEntityProvider<>());
        //register(LoggingFeature.class);
        register(LoggingFilter.class);
    }
}*/