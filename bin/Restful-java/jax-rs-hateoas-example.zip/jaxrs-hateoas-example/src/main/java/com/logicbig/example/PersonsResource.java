package com.logicbig.example;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.*;
import java.util.Arrays;
import java.util.List;

@Path("persons")
public class PersonsResource {

    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Response getPersons(@Context UriInfo uriInfo) {
        List<Person> persons = PersonService.Instance.getPersons();
        persons.forEach(p -> initLinks(p, uriInfo));

        GenericEntity<List<Person>> genericEntity =
                new GenericEntity<List<Person>>(persons) {};

        Link self = Link.fromUriBuilder(uriInfo.getAbsolutePathBuilder())
                        .rel("self").build();
        Link historyLink = Link.fromUriBuilder(uriInfo.getAbsolutePathBuilder()
                                                      .path("history")
                                                      .queryParam("year", "1990"))
                               .rel("history").build();

        return Response.ok(genericEntity)
                       .links(self, historyLink).build();
    }

    @GET
    @Produces(MediaType.APPLICATION_XML)
    @Path("{id}")
    public Response getPerson(@PathParam("id") int id, @Context UriInfo uriInfo) {
        Person person = PersonService.Instance.getPersonById(id);

        Link self = Link.fromUriBuilder(uriInfo.getAbsolutePathBuilder())
                        .rel("self").build();

        return Response.ok(person)
                       .links(self).build();
    }


    private void initLinks(Person person, UriInfo uriInfo) {
        //create self link
        UriBuilder uriBuilder = uriInfo.getRequestUriBuilder();
        uriBuilder = uriBuilder.path(Integer.toString(person.getId()));
        Link.Builder linkBuilder = Link.fromUriBuilder(uriBuilder);
        Link selfLink = linkBuilder.rel("self").build();
        //also we can add other meta-data by using: linkBuilder.param(..),
        // linkBuilder.type(..), linkBuilder.title(..)
        person.setLinks(Arrays.asList(selfLink));
    }
}