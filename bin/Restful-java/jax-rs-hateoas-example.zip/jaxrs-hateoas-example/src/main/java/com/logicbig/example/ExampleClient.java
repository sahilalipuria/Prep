package com.logicbig.example;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class ExampleClient {
    public static void main(String[] args) {
        Client client = ClientBuilder.newClient();
        WebTarget target =
                client.target("http://localhost:8080/persons");
        Response response = target.request()
                                  .get();
        System.out.printf("status: %s%n", response.getStatus());
        System.out.println("-- response headers --");
        response.getHeaders().entrySet().stream()
                .forEach(e -> System.out.println(e.getKey() + " = " + e.getValue()));
        System.out.printf("-- response body --%n%s%n", response.readEntity(String.class)
                                                               //just for pretty xml output
                                                               .replaceAll("(</\\w+>)", "$1\n")
                                                               .replaceAll("/>", "/>\n"));
    }
}