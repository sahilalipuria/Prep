package com.logicbig.example;

import java.util.ArrayList;
import java.util.List;

public enum PersonService {
    Instance;

    public List<Person> getPersons() {
        List<Person> persons = new ArrayList<>();
        Person person = new Person(1, "Tina", 35);
        persons.add(person);
        Person person2 = new Person(2, "Charlie", 40);
        persons.add(person2);
        return persons;
    }

    public Person getPersonById(int id) {
        if (id == 1) {
            return new Person(1, "Tina", 35);
        } else if (id == 2) {
            return new Person(2, "Charlie", 40);
        }
        return null;
    }
}