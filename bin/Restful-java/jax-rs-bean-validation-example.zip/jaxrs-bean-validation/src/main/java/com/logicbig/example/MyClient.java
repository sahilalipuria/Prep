package com.logicbig.example;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;
import java.util.concurrent.Future;

public class MyClient {

    public static void main(String[] args) throws Exception {
        Form form = new Form();
        form.param("name", null)
            .param("address", null)
            .param("phone-number", "343-343-343");

        Client client = ClientBuilder.newBuilder().build();
        WebTarget target =
                client.target("http://localhost:8080/customers");
        Future<String> future = target.request(MediaType.APPLICATION_FORM_URLENCODED)
                                      .buildPost(Entity.form(form)).submit(String.class);
        System.out.println(future.get());
    }
}